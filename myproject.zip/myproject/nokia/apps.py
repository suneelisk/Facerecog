from django.apps import AppConfig


class NokiaConfig(AppConfig):
    name = 'nokia'
